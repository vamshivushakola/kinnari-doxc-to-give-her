/*
 * ----------------------------------------------------------------
 * --- WARNING: THIS FILE IS GENERATED AND WILL BE OVERWRITTEN! ---
 * --- Generated at May 5, 2016 2:23:07 PM                      ---
 * ----------------------------------------------------------------
 */
package com.asianpaints.core.jalo;

import com.asianpaints.core.constants.AsianpaintsCoreConstants;
import com.asianpaints.core.jalo.ApparelProduct;
import com.asianpaints.core.jalo.ApparelSizeVariantProduct;
import com.asianpaints.core.jalo.ApparelStyleVariantProduct;
import com.asianpaints.core.jalo.AsianpaintsSizeVariantProduct;
import com.asianpaints.core.jalo.AsianpaintsStyleVariantProduct;
import com.asianpaints.core.jalo.ComingSoonNotiFyCustomer;
import com.asianpaints.core.jalo.ElectronicsColorVariantProduct;
import com.asianpaints.core.jalo.NotiFyCustomer;
import de.hybris.platform.jalo.GenericItem;
import de.hybris.platform.jalo.Item;
import de.hybris.platform.jalo.Item.AttributeMode;
import de.hybris.platform.jalo.JaloBusinessException;
import de.hybris.platform.jalo.JaloSystemException;
import de.hybris.platform.jalo.SessionContext;
import de.hybris.platform.jalo.extension.Extension;
import de.hybris.platform.jalo.order.AbstractOrder;
import de.hybris.platform.jalo.order.AbstractOrderEntry;
import de.hybris.platform.jalo.order.Cart;
import de.hybris.platform.jalo.order.Order;
import de.hybris.platform.jalo.product.Product;
import de.hybris.platform.jalo.type.ComposedType;
import de.hybris.platform.jalo.type.JaloGenericCreationException;
import de.hybris.platform.jalo.user.Customer;
import de.hybris.platform.jalo.user.User;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Generated class for type <code>AsianpaintsCoreManager</code>.
 */
@SuppressWarnings({"deprecation","unused","cast","PMD"})
public abstract class GeneratedAsianpaintsCoreManager extends Extension
{
	protected static final Map<String, Map<String, AttributeMode>> DEFAULT_INITIAL_ATTRIBUTES;
	static
	{
		final Map<String, Map<String, AttributeMode>> ttmp = new HashMap();
		Map<String, AttributeMode> tmp = new HashMap<String, AttributeMode>();
		tmp.put("selectedAddons", AttributeMode.INITIAL);
		ttmp.put("de.hybris.platform.jalo.order.AbstractOrderEntry", Collections.unmodifiableMap(tmp));
		tmp = new HashMap<String, AttributeMode>();
		tmp.put("isCommingSoon", AttributeMode.INITIAL);
		ttmp.put("de.hybris.platform.jalo.product.Product", Collections.unmodifiableMap(tmp));
		tmp = new HashMap<String, AttributeMode>();
		tmp.put("contactNo", AttributeMode.INITIAL);
		tmp.put("DOB", AttributeMode.INITIAL);
		tmp.put("availableCreditPoints", AttributeMode.INITIAL);
		ttmp.put("de.hybris.platform.jalo.user.Customer", Collections.unmodifiableMap(tmp));
		tmp = new HashMap<String, AttributeMode>();
		tmp.put("eligibleCreditPoints", AttributeMode.INITIAL);
		ttmp.put("de.hybris.platform.jalo.order.Cart", Collections.unmodifiableMap(tmp));
		tmp = new HashMap<String, AttributeMode>();
		tmp.put("usedCreditPoints", AttributeMode.INITIAL);
		ttmp.put("de.hybris.platform.jalo.order.Order", Collections.unmodifiableMap(tmp));
		DEFAULT_INITIAL_ATTRIBUTES = ttmp;
	}
	@Override
	public Map<String, AttributeMode> getDefaultAttributeModes(final Class<? extends Item> itemClass)
	{
		Map<String, AttributeMode> ret = new HashMap<>();
		final Map<String, AttributeMode> attr = DEFAULT_INITIAL_ATTRIBUTES.get(itemClass.getName());
		if (attr != null)
		{
			ret.putAll(attr);
		}
		return ret;
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>Customer.availableCreditPoints</code> attribute.
	 * @return the availableCreditPoints - It holds information about customer creditPoints.
	 */
	public Double getAvailableCreditPoints(final SessionContext ctx, final Customer item)
	{
		return (Double)item.getProperty( ctx, AsianpaintsCoreConstants.Attributes.Customer.AVAILABLECREDITPOINTS);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>Customer.availableCreditPoints</code> attribute.
	 * @return the availableCreditPoints - It holds information about customer creditPoints.
	 */
	public Double getAvailableCreditPoints(final Customer item)
	{
		return getAvailableCreditPoints( getSession().getSessionContext(), item );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>Customer.availableCreditPoints</code> attribute. 
	 * @return the availableCreditPoints - It holds information about customer creditPoints.
	 */
	public double getAvailableCreditPointsAsPrimitive(final SessionContext ctx, final Customer item)
	{
		Double value = getAvailableCreditPoints( ctx,item );
		return value != null ? value.doubleValue() : 0.0d;
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>Customer.availableCreditPoints</code> attribute. 
	 * @return the availableCreditPoints - It holds information about customer creditPoints.
	 */
	public double getAvailableCreditPointsAsPrimitive(final Customer item)
	{
		return getAvailableCreditPointsAsPrimitive( getSession().getSessionContext(), item );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>Customer.availableCreditPoints</code> attribute. 
	 * @param value the availableCreditPoints - It holds information about customer creditPoints.
	 */
	public void setAvailableCreditPoints(final SessionContext ctx, final Customer item, final Double value)
	{
		item.setProperty(ctx, AsianpaintsCoreConstants.Attributes.Customer.AVAILABLECREDITPOINTS,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>Customer.availableCreditPoints</code> attribute. 
	 * @param value the availableCreditPoints - It holds information about customer creditPoints.
	 */
	public void setAvailableCreditPoints(final Customer item, final Double value)
	{
		setAvailableCreditPoints( getSession().getSessionContext(), item, value );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>Customer.availableCreditPoints</code> attribute. 
	 * @param value the availableCreditPoints - It holds information about customer creditPoints.
	 */
	public void setAvailableCreditPoints(final SessionContext ctx, final Customer item, final double value)
	{
		setAvailableCreditPoints( ctx, item, Double.valueOf( value ) );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>Customer.availableCreditPoints</code> attribute. 
	 * @param value the availableCreditPoints - It holds information about customer creditPoints.
	 */
	public void setAvailableCreditPoints(final Customer item, final double value)
	{
		setAvailableCreditPoints( getSession().getSessionContext(), item, value );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>Customer.contactNo</code> attribute.
	 * @return the contactNo
	 */
	public String getContactNo(final SessionContext ctx, final Customer item)
	{
		return (String)item.getProperty( ctx, AsianpaintsCoreConstants.Attributes.Customer.CONTACTNO);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>Customer.contactNo</code> attribute.
	 * @return the contactNo
	 */
	public String getContactNo(final Customer item)
	{
		return getContactNo( getSession().getSessionContext(), item );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>Customer.contactNo</code> attribute. 
	 * @param value the contactNo
	 */
	public void setContactNo(final SessionContext ctx, final Customer item, final String value)
	{
		item.setProperty(ctx, AsianpaintsCoreConstants.Attributes.Customer.CONTACTNO,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>Customer.contactNo</code> attribute. 
	 * @param value the contactNo
	 */
	public void setContactNo(final Customer item, final String value)
	{
		setContactNo( getSession().getSessionContext(), item, value );
	}
	
	public ApparelProduct createApparelProduct(final SessionContext ctx, final Map attributeValues)
	{
		try
		{
			ComposedType type = getTenant().getJaloConnection().getTypeManager().getComposedType( AsianpaintsCoreConstants.TC.APPARELPRODUCT );
			return (ApparelProduct)type.newInstance( ctx, attributeValues );
		}
		catch( JaloGenericCreationException e)
		{
			final Throwable cause = e.getCause();
			throw (cause instanceof RuntimeException ?
			(RuntimeException)cause
			:
			new JaloSystemException( cause, cause.getMessage(), e.getErrorCode() ) );
		}
		catch( JaloBusinessException e )
		{
			throw new JaloSystemException( e ,"error creating ApparelProduct : "+e.getMessage(), 0 );
		}
	}
	
	public ApparelProduct createApparelProduct(final Map attributeValues)
	{
		return createApparelProduct( getSession().getSessionContext(), attributeValues );
	}
	
	public ApparelSizeVariantProduct createApparelSizeVariantProduct(final SessionContext ctx, final Map attributeValues)
	{
		try
		{
			ComposedType type = getTenant().getJaloConnection().getTypeManager().getComposedType( AsianpaintsCoreConstants.TC.APPARELSIZEVARIANTPRODUCT );
			return (ApparelSizeVariantProduct)type.newInstance( ctx, attributeValues );
		}
		catch( JaloGenericCreationException e)
		{
			final Throwable cause = e.getCause();
			throw (cause instanceof RuntimeException ?
			(RuntimeException)cause
			:
			new JaloSystemException( cause, cause.getMessage(), e.getErrorCode() ) );
		}
		catch( JaloBusinessException e )
		{
			throw new JaloSystemException( e ,"error creating ApparelSizeVariantProduct : "+e.getMessage(), 0 );
		}
	}
	
	public ApparelSizeVariantProduct createApparelSizeVariantProduct(final Map attributeValues)
	{
		return createApparelSizeVariantProduct( getSession().getSessionContext(), attributeValues );
	}
	
	public ApparelStyleVariantProduct createApparelStyleVariantProduct(final SessionContext ctx, final Map attributeValues)
	{
		try
		{
			ComposedType type = getTenant().getJaloConnection().getTypeManager().getComposedType( AsianpaintsCoreConstants.TC.APPARELSTYLEVARIANTPRODUCT );
			return (ApparelStyleVariantProduct)type.newInstance( ctx, attributeValues );
		}
		catch( JaloGenericCreationException e)
		{
			final Throwable cause = e.getCause();
			throw (cause instanceof RuntimeException ?
			(RuntimeException)cause
			:
			new JaloSystemException( cause, cause.getMessage(), e.getErrorCode() ) );
		}
		catch( JaloBusinessException e )
		{
			throw new JaloSystemException( e ,"error creating ApparelStyleVariantProduct : "+e.getMessage(), 0 );
		}
	}
	
	public ApparelStyleVariantProduct createApparelStyleVariantProduct(final Map attributeValues)
	{
		return createApparelStyleVariantProduct( getSession().getSessionContext(), attributeValues );
	}
	
	public AsianpaintsSizeVariantProduct createAsianpaintsSizeVariantProduct(final SessionContext ctx, final Map attributeValues)
	{
		try
		{
			ComposedType type = getTenant().getJaloConnection().getTypeManager().getComposedType( AsianpaintsCoreConstants.TC.ASIANPAINTSSIZEVARIANTPRODUCT );
			return (AsianpaintsSizeVariantProduct)type.newInstance( ctx, attributeValues );
		}
		catch( JaloGenericCreationException e)
		{
			final Throwable cause = e.getCause();
			throw (cause instanceof RuntimeException ?
			(RuntimeException)cause
			:
			new JaloSystemException( cause, cause.getMessage(), e.getErrorCode() ) );
		}
		catch( JaloBusinessException e )
		{
			throw new JaloSystemException( e ,"error creating AsianpaintsSizeVariantProduct : "+e.getMessage(), 0 );
		}
	}
	
	public AsianpaintsSizeVariantProduct createAsianpaintsSizeVariantProduct(final Map attributeValues)
	{
		return createAsianpaintsSizeVariantProduct( getSession().getSessionContext(), attributeValues );
	}
	
	public AsianpaintsStyleVariantProduct createAsianpaintsStyleVariantProduct(final SessionContext ctx, final Map attributeValues)
	{
		try
		{
			ComposedType type = getTenant().getJaloConnection().getTypeManager().getComposedType( AsianpaintsCoreConstants.TC.ASIANPAINTSSTYLEVARIANTPRODUCT );
			return (AsianpaintsStyleVariantProduct)type.newInstance( ctx, attributeValues );
		}
		catch( JaloGenericCreationException e)
		{
			final Throwable cause = e.getCause();
			throw (cause instanceof RuntimeException ?
			(RuntimeException)cause
			:
			new JaloSystemException( cause, cause.getMessage(), e.getErrorCode() ) );
		}
		catch( JaloBusinessException e )
		{
			throw new JaloSystemException( e ,"error creating AsianpaintsStyleVariantProduct : "+e.getMessage(), 0 );
		}
	}
	
	public AsianpaintsStyleVariantProduct createAsianpaintsStyleVariantProduct(final Map attributeValues)
	{
		return createAsianpaintsStyleVariantProduct( getSession().getSessionContext(), attributeValues );
	}
	
	public ComingSoonNotiFyCustomer createComingSoonNotiFyCustomer(final SessionContext ctx, final Map attributeValues)
	{
		try
		{
			ComposedType type = getTenant().getJaloConnection().getTypeManager().getComposedType( AsianpaintsCoreConstants.TC.COMINGSOONNOTIFYCUSTOMER );
			return (ComingSoonNotiFyCustomer)type.newInstance( ctx, attributeValues );
		}
		catch( JaloGenericCreationException e)
		{
			final Throwable cause = e.getCause();
			throw (cause instanceof RuntimeException ?
			(RuntimeException)cause
			:
			new JaloSystemException( cause, cause.getMessage(), e.getErrorCode() ) );
		}
		catch( JaloBusinessException e )
		{
			throw new JaloSystemException( e ,"error creating ComingSoonNotiFyCustomer : "+e.getMessage(), 0 );
		}
	}
	
	public ComingSoonNotiFyCustomer createComingSoonNotiFyCustomer(final Map attributeValues)
	{
		return createComingSoonNotiFyCustomer( getSession().getSessionContext(), attributeValues );
	}
	
	public ElectronicsColorVariantProduct createElectronicsColorVariantProduct(final SessionContext ctx, final Map attributeValues)
	{
		try
		{
			ComposedType type = getTenant().getJaloConnection().getTypeManager().getComposedType( AsianpaintsCoreConstants.TC.ELECTRONICSCOLORVARIANTPRODUCT );
			return (ElectronicsColorVariantProduct)type.newInstance( ctx, attributeValues );
		}
		catch( JaloGenericCreationException e)
		{
			final Throwable cause = e.getCause();
			throw (cause instanceof RuntimeException ?
			(RuntimeException)cause
			:
			new JaloSystemException( cause, cause.getMessage(), e.getErrorCode() ) );
		}
		catch( JaloBusinessException e )
		{
			throw new JaloSystemException( e ,"error creating ElectronicsColorVariantProduct : "+e.getMessage(), 0 );
		}
	}
	
	public ElectronicsColorVariantProduct createElectronicsColorVariantProduct(final Map attributeValues)
	{
		return createElectronicsColorVariantProduct( getSession().getSessionContext(), attributeValues );
	}
	
	public NotiFyCustomer createNotiFyCustomer(final SessionContext ctx, final Map attributeValues)
	{
		try
		{
			ComposedType type = getTenant().getJaloConnection().getTypeManager().getComposedType( AsianpaintsCoreConstants.TC.NOTIFYCUSTOMER );
			return (NotiFyCustomer)type.newInstance( ctx, attributeValues );
		}
		catch( JaloGenericCreationException e)
		{
			final Throwable cause = e.getCause();
			throw (cause instanceof RuntimeException ?
			(RuntimeException)cause
			:
			new JaloSystemException( cause, cause.getMessage(), e.getErrorCode() ) );
		}
		catch( JaloBusinessException e )
		{
			throw new JaloSystemException( e ,"error creating NotiFyCustomer : "+e.getMessage(), 0 );
		}
	}
	
	public NotiFyCustomer createNotiFyCustomer(final Map attributeValues)
	{
		return createNotiFyCustomer( getSession().getSessionContext(), attributeValues );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>Customer.DOB</code> attribute.
	 * @return the DOB
	 */
	public Date getDOB(final SessionContext ctx, final Customer item)
	{
		return (Date)item.getProperty( ctx, AsianpaintsCoreConstants.Attributes.Customer.DOB);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>Customer.DOB</code> attribute.
	 * @return the DOB
	 */
	public Date getDOB(final Customer item)
	{
		return getDOB( getSession().getSessionContext(), item );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>Customer.DOB</code> attribute. 
	 * @param value the DOB
	 */
	public void setDOB(final SessionContext ctx, final Customer item, final Date value)
	{
		item.setProperty(ctx, AsianpaintsCoreConstants.Attributes.Customer.DOB,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>Customer.DOB</code> attribute. 
	 * @param value the DOB
	 */
	public void setDOB(final Customer item, final Date value)
	{
		setDOB( getSession().getSessionContext(), item, value );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>Cart.eligibleCreditPoints</code> attribute.
	 * @return the eligibleCreditPoints - It holds information about customer creditPoints.
	 */
	public Double getEligibleCreditPoints(final SessionContext ctx, final Cart item)
	{
		return (Double)item.getProperty( ctx, AsianpaintsCoreConstants.Attributes.Cart.ELIGIBLECREDITPOINTS);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>Cart.eligibleCreditPoints</code> attribute.
	 * @return the eligibleCreditPoints - It holds information about customer creditPoints.
	 */
	public Double getEligibleCreditPoints(final Cart item)
	{
		return getEligibleCreditPoints( getSession().getSessionContext(), item );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>Cart.eligibleCreditPoints</code> attribute. 
	 * @return the eligibleCreditPoints - It holds information about customer creditPoints.
	 */
	public double getEligibleCreditPointsAsPrimitive(final SessionContext ctx, final Cart item)
	{
		Double value = getEligibleCreditPoints( ctx,item );
		return value != null ? value.doubleValue() : 0.0d;
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>Cart.eligibleCreditPoints</code> attribute. 
	 * @return the eligibleCreditPoints - It holds information about customer creditPoints.
	 */
	public double getEligibleCreditPointsAsPrimitive(final Cart item)
	{
		return getEligibleCreditPointsAsPrimitive( getSession().getSessionContext(), item );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>Cart.eligibleCreditPoints</code> attribute. 
	 * @param value the eligibleCreditPoints - It holds information about customer creditPoints.
	 */
	public void setEligibleCreditPoints(final SessionContext ctx, final Cart item, final Double value)
	{
		item.setProperty(ctx, AsianpaintsCoreConstants.Attributes.Cart.ELIGIBLECREDITPOINTS,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>Cart.eligibleCreditPoints</code> attribute. 
	 * @param value the eligibleCreditPoints - It holds information about customer creditPoints.
	 */
	public void setEligibleCreditPoints(final Cart item, final Double value)
	{
		setEligibleCreditPoints( getSession().getSessionContext(), item, value );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>Cart.eligibleCreditPoints</code> attribute. 
	 * @param value the eligibleCreditPoints - It holds information about customer creditPoints.
	 */
	public void setEligibleCreditPoints(final SessionContext ctx, final Cart item, final double value)
	{
		setEligibleCreditPoints( ctx, item, Double.valueOf( value ) );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>Cart.eligibleCreditPoints</code> attribute. 
	 * @param value the eligibleCreditPoints - It holds information about customer creditPoints.
	 */
	public void setEligibleCreditPoints(final Cart item, final double value)
	{
		setEligibleCreditPoints( getSession().getSessionContext(), item, value );
	}
	
	@Override
	public String getName()
	{
		return AsianpaintsCoreConstants.EXTENSIONNAME;
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>Product.isCommingSoon</code> attribute.
	 * @return the isCommingSoon - Comming Soon Products
	 */
	public Boolean isIsCommingSoon(final SessionContext ctx, final Product item)
	{
		return (Boolean)item.getProperty( ctx, AsianpaintsCoreConstants.Attributes.Product.ISCOMMINGSOON);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>Product.isCommingSoon</code> attribute.
	 * @return the isCommingSoon - Comming Soon Products
	 */
	public Boolean isIsCommingSoon(final Product item)
	{
		return isIsCommingSoon( getSession().getSessionContext(), item );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>Product.isCommingSoon</code> attribute. 
	 * @return the isCommingSoon - Comming Soon Products
	 */
	public boolean isIsCommingSoonAsPrimitive(final SessionContext ctx, final Product item)
	{
		Boolean value = isIsCommingSoon( ctx,item );
		return value != null ? value.booleanValue() : false;
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>Product.isCommingSoon</code> attribute. 
	 * @return the isCommingSoon - Comming Soon Products
	 */
	public boolean isIsCommingSoonAsPrimitive(final Product item)
	{
		return isIsCommingSoonAsPrimitive( getSession().getSessionContext(), item );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>Product.isCommingSoon</code> attribute. 
	 * @param value the isCommingSoon - Comming Soon Products
	 */
	public void setIsCommingSoon(final SessionContext ctx, final Product item, final Boolean value)
	{
		item.setProperty(ctx, AsianpaintsCoreConstants.Attributes.Product.ISCOMMINGSOON,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>Product.isCommingSoon</code> attribute. 
	 * @param value the isCommingSoon - Comming Soon Products
	 */
	public void setIsCommingSoon(final Product item, final Boolean value)
	{
		setIsCommingSoon( getSession().getSessionContext(), item, value );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>Product.isCommingSoon</code> attribute. 
	 * @param value the isCommingSoon - Comming Soon Products
	 */
	public void setIsCommingSoon(final SessionContext ctx, final Product item, final boolean value)
	{
		setIsCommingSoon( ctx, item, Boolean.valueOf( value ) );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>Product.isCommingSoon</code> attribute. 
	 * @param value the isCommingSoon - Comming Soon Products
	 */
	public void setIsCommingSoon(final Product item, final boolean value)
	{
		setIsCommingSoon( getSession().getSessionContext(), item, value );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>AbstractOrderEntry.selectedAddons</code> attribute.
	 * @return the selectedAddons - Selected addons
	 */
	public List<String> getSelectedAddons(final SessionContext ctx, final AbstractOrderEntry item)
	{
		List<String> coll = (List<String>)item.getProperty( ctx, AsianpaintsCoreConstants.Attributes.AbstractOrderEntry.SELECTEDADDONS);
		return coll != null ? coll : Collections.EMPTY_LIST;
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>AbstractOrderEntry.selectedAddons</code> attribute.
	 * @return the selectedAddons - Selected addons
	 */
	public List<String> getSelectedAddons(final AbstractOrderEntry item)
	{
		return getSelectedAddons( getSession().getSessionContext(), item );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>AbstractOrderEntry.selectedAddons</code> attribute. 
	 * @param value the selectedAddons - Selected addons
	 */
	public void setSelectedAddons(final SessionContext ctx, final AbstractOrderEntry item, final List<String> value)
	{
		item.setProperty(ctx, AsianpaintsCoreConstants.Attributes.AbstractOrderEntry.SELECTEDADDONS,value == null || !value.isEmpty() ? value : null );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>AbstractOrderEntry.selectedAddons</code> attribute. 
	 * @param value the selectedAddons - Selected addons
	 */
	public void setSelectedAddons(final AbstractOrderEntry item, final List<String> value)
	{
		setSelectedAddons( getSession().getSessionContext(), item, value );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>Order.usedCreditPoints</code> attribute.
	 * @return the usedCreditPoints - Used Credit Points
	 */
	public Double getUsedCreditPoints(final SessionContext ctx, final Order item)
	{
		return (Double)item.getProperty( ctx, AsianpaintsCoreConstants.Attributes.Order.USEDCREDITPOINTS);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>Order.usedCreditPoints</code> attribute.
	 * @return the usedCreditPoints - Used Credit Points
	 */
	public Double getUsedCreditPoints(final Order item)
	{
		return getUsedCreditPoints( getSession().getSessionContext(), item );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>Order.usedCreditPoints</code> attribute. 
	 * @return the usedCreditPoints - Used Credit Points
	 */
	public double getUsedCreditPointsAsPrimitive(final SessionContext ctx, final Order item)
	{
		Double value = getUsedCreditPoints( ctx,item );
		return value != null ? value.doubleValue() : 0.0d;
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>Order.usedCreditPoints</code> attribute. 
	 * @return the usedCreditPoints - Used Credit Points
	 */
	public double getUsedCreditPointsAsPrimitive(final Order item)
	{
		return getUsedCreditPointsAsPrimitive( getSession().getSessionContext(), item );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>Order.usedCreditPoints</code> attribute. 
	 * @param value the usedCreditPoints - Used Credit Points
	 */
	public void setUsedCreditPoints(final SessionContext ctx, final Order item, final Double value)
	{
		item.setProperty(ctx, AsianpaintsCoreConstants.Attributes.Order.USEDCREDITPOINTS,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>Order.usedCreditPoints</code> attribute. 
	 * @param value the usedCreditPoints - Used Credit Points
	 */
	public void setUsedCreditPoints(final Order item, final Double value)
	{
		setUsedCreditPoints( getSession().getSessionContext(), item, value );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>Order.usedCreditPoints</code> attribute. 
	 * @param value the usedCreditPoints - Used Credit Points
	 */
	public void setUsedCreditPoints(final SessionContext ctx, final Order item, final double value)
	{
		setUsedCreditPoints( ctx, item, Double.valueOf( value ) );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>Order.usedCreditPoints</code> attribute. 
	 * @param value the usedCreditPoints - Used Credit Points
	 */
	public void setUsedCreditPoints(final Order item, final double value)
	{
		setUsedCreditPoints( getSession().getSessionContext(), item, value );
	}
	
}
