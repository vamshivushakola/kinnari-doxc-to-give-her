/*
 * ----------------------------------------------------------------
 * --- WARNING: THIS FILE IS GENERATED AND WILL BE OVERWRITTEN! ---
 * --- Generated at May 5, 2016 2:23:07 PM                      ---
 * ----------------------------------------------------------------
 */
package com.asianpaints.cockpits.constants;

/**
 * @deprecated use constants in Model classes instead
 */
@Deprecated
@SuppressWarnings({"unused","cast","PMD"})
public class GeneratedAsianpaintsCockpitsConstants
{
	public static final String EXTENSIONNAME = "asianpaintscockpits";
	
	protected GeneratedAsianpaintsCockpitsConstants()
	{
		// private constructor
	}
	
	
}
